# 🌟 BONUS: Advanced Feature Components

These are optional premium features you can add to take PawPad to the next level!

## 1. 📸 Photo Gallery Component

```javascript
// PhotoGallery.jsx
import React, { useState } from 'react';
import { Camera, X, Download, Share2, Heart } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

const PhotoGallery = () => {
  const [photos, setPhotos] = useState([]);
  const [selectedPhoto, setSelectedPhoto] = useState(null);

  const handleFileUpload = (e) => {
    const files = Array.from(e.target.files);
    const newPhotos = files.map(file => ({
      id: Date.now() + Math.random(),
      url: URL.createObjectURL(file),
      date: new Date().toISOString(),
      liked: false
    }));
    setPhotos([...newPhotos, ...photos]);
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h3 className="text-xs font-black text-[#8A7560] uppercase tracking-wider">
          Photo Memories
        </h3>
        <label className="px-4 py-2 bg-[#E8621A] text-white rounded-xl text-xs font-black cursor-pointer hover:bg-[#D55614] transition-all">
          <input type="file" accept="image/*" multiple onChange={handleFileUpload} className="hidden" />
          <Camera size={14} className="inline mr-2" />
          Add Photo
        </label>
      </div>

      {photos.length === 0 ? (
        <div className="text-center py-12 bg-stone-50 rounded-3xl">
          <Camera size={48} className="mx-auto text-stone-300 mb-3" />
          <p className="text-sm font-bold text-stone-400">No photos yet</p>
          <p className="text-xs text-stone-300">Start capturing memories!</p>
        </div>
      ) : (
        <div className="grid grid-cols-3 gap-3">
          {photos.map(photo => (
            <motion.div
              key={photo.id}
              initial={{ scale: 0, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              className="aspect-square rounded-2xl overflow-hidden cursor-pointer relative group"
              onClick={() => setSelectedPhoto(photo)}
            >
              <img src={photo.url} alt="Pet" className="w-full h-full object-cover" />
              <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                <Camera size={24} className="text-white" />
              </div>
            </motion.div>
          ))}
        </div>
      )}

      {/* Photo Viewer Modal */}
      <AnimatePresence>
        {selectedPhoto && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-6 bg-black/90">
            <motion.div
              initial={{ scale: 0.8, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.8, opacity: 0 }}
              className="relative w-full max-w-2xl"
            >
              <button
                onClick={() => setSelectedPhoto(null)}
                className="absolute -top-12 right-0 p-2 text-white hover:bg-white/10 rounded-full"
              >
                <X size={24} />
              </button>
              <img 
                src={selectedPhoto.url} 
                alt="Pet" 
                className="w-full h-auto rounded-3xl shadow-2xl" 
              />
              <div className="flex gap-3 justify-center mt-6">
                <button className="px-6 py-3 bg-white text-[#E8621A] rounded-2xl font-bold text-sm flex items-center gap-2">
                  <Heart size={16} /> Like
                </button>
                <button className="px-6 py-3 bg-white text-[#E8621A] rounded-2xl font-bold text-sm flex items-center gap-2">
                  <Share2 size={16} /> Share
                </button>
                <button className="px-6 py-3 bg-white text-[#E8621A] rounded-2xl font-bold text-sm flex items-center gap-2">
                  <Download size={16} /> Save
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default PhotoGallery;
```

## 2. 📅 Appointment Scheduler

```javascript
// AppointmentScheduler.jsx
import React, { useState } from 'react';
import { Calendar, Clock, MapPin, Plus, Trash2 } from 'lucide-react';
import { motion } from 'framer-motion';

const AppointmentScheduler = () => {
  const [appointments, setAppointments] = useState([
    {
      id: 1,
      type: 'Vet Checkup',
      date: '2024-04-15',
      time: '10:00 AM',
      location: 'Happy Paws Clinic',
      notes: 'Annual checkup'
    }
  ]);
  const [showForm, setShowForm] = useState(false);
  const [newAppt, setNewAppt] = useState({
    type: '',
    date: '',
    time: '',
    location: '',
    notes: ''
  });

  const addAppointment = () => {
    if (newAppt.type && newAppt.date) {
      setAppointments([
        ...appointments,
        { ...newAppt, id: Date.now() }
      ]);
      setNewAppt({ type: '', date: '', time: '', location: '', notes: '' });
      setShowForm(false);
    }
  };

  const deleteAppointment = (id) => {
    setAppointments(appointments.filter(a => a.id !== id));
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h3 className="text-xs font-black text-[#8A7560] uppercase tracking-wider">
          Upcoming Appointments
        </h3>
        <button
          onClick={() => setShowForm(!showForm)}
          className="px-4 py-2 bg-[#E8621A] text-white rounded-xl text-xs font-black hover:bg-[#D55614] transition-all"
        >
          <Plus size={14} className="inline mr-1" />
          {showForm ? 'Cancel' : 'New'}
        </button>
      </div>

      {showForm && (
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-stone-50 p-6 rounded-3xl border-2 border-[#EDE0CE]"
        >
          <div className="space-y-4">
            <select
              value={newAppt.type}
              onChange={(e) => setNewAppt({ ...newAppt, type: e.target.value })}
              className="w-full p-4 bg-white rounded-2xl border-2 border-transparent focus:border-[#E8621A] outline-none font-bold"
            >
              <option value="">Select Type</option>
              <option value="Vet Checkup">Vet Checkup</option>
              <option value="Vaccination">Vaccination</option>
              <option value="Grooming">Grooming</option>
              <option value="Training">Training</option>
              <option value="Other">Other</option>
            </select>

            <div className="grid grid-cols-2 gap-4">
              <input
                type="date"
                value={newAppt.date}
                onChange={(e) => setNewAppt({ ...newAppt, date: e.target.value })}
                className="p-4 bg-white rounded-2xl border-2 border-transparent focus:border-[#E8621A] outline-none font-bold"
              />
              <input
                type="time"
                value={newAppt.time}
                onChange={(e) => setNewAppt({ ...newAppt, time: e.target.value })}
                className="p-4 bg-white rounded-2xl border-2 border-transparent focus:border-[#E8621A] outline-none font-bold"
              />
            </div>

            <input
              type="text"
              placeholder="Location"
              value={newAppt.location}
              onChange={(e) => setNewAppt({ ...newAppt, location: e.target.value })}
              className="w-full p-4 bg-white rounded-2xl border-2 border-transparent focus:border-[#E8621A] outline-none font-bold"
            />

            <textarea
              placeholder="Notes (optional)"
              value={newAppt.notes}
              onChange={(e) => setNewAppt({ ...newAppt, notes: e.target.value })}
              className="w-full p-4 bg-white rounded-2xl border-2 border-transparent focus:border-[#E8621A] outline-none font-bold resize-none"
              rows={3}
            />

            <button
              onClick={addAppointment}
              className="w-full py-4 bg-[#E8621A] text-white rounded-2xl font-black text-sm hover:bg-[#D55614] transition-all"
            >
              Save Appointment
            </button>
          </div>
        </motion.div>
      )}

      <div className="space-y-3">
        {appointments.map(appt => (
          <motion.div
            key={appt.id}
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            className="bg-white p-6 rounded-3xl border-2 border-[#EDE0CE] shadow-sm"
          >
            <div className="flex justify-between items-start mb-3">
              <div>
                <h4 className="font-black text-[#423D38] mb-1">{appt.type}</h4>
                <div className="flex items-center gap-4 text-xs text-stone-500 font-medium">
                  <span className="flex items-center gap-1">
                    <Calendar size={14} /> {appt.date}
                  </span>
                  <span className="flex items-center gap-1">
                    <Clock size={14} /> {appt.time}
                  </span>
                </div>
              </div>
              <button
                onClick={() => deleteAppointment(appt.id)}
                className="p-2 hover:bg-red-50 rounded-xl text-red-400 transition-colors"
              >
                <Trash2 size={16} />
              </button>
            </div>
            {appt.location && (
              <div className="flex items-center gap-2 text-sm text-[#8A7560] font-medium mb-2">
                <MapPin size={14} />
                {appt.location}
              </div>
            )}
            {appt.notes && (
              <p className="text-sm text-stone-600 italic">{appt.notes}</p>
            )}
          </motion.div>
        ))}
      </div>
    </div>
  );
};

export default AppointmentScheduler;
```

## 3. 💰 Expense Tracker

```javascript
// ExpenseTracker.jsx
import React, { useState, useEffect } from 'react';
import { DollarSign, TrendingUp, ShoppingCart, Stethoscope, Scissors } from 'lucide-react';
import { motion } from 'framer-motion';

const ExpenseTracker = () => {
  const [expenses, setExpenses] = useState([]);
  const [newExpense, setNewExpense] = useState({
    category: '',
    amount: '',
    description: '',
    date: new Date().toISOString().split('T')[0]
  });

  const categories = [
    { name: 'Food', icon: ShoppingCart, color: 'text-orange-500', bg: 'bg-orange-50' },
    { name: 'Medical', icon: Stethoscope, color: 'text-red-500', bg: 'bg-red-50' },
    { name: 'Grooming', icon: Scissors, color: 'text-purple-500', bg: 'bg-purple-50' },
    { name: 'Toys', icon: Star, color: 'text-yellow-500', bg: 'bg-yellow-50' },
    { name: 'Other', icon: DollarSign, color: 'text-blue-500', bg: 'bg-blue-50' }
  ];

  const addExpense = () => {
    if (newExpense.category && newExpense.amount) {
      setExpenses([
        { ...newExpense, id: Date.now(), amount: parseFloat(newExpense.amount) },
        ...expenses
      ]);
      setNewExpense({ category: '', amount: '', description: '', date: new Date().toISOString().split('T')[0] });
    }
  };

  const totalSpent = expenses.reduce((sum, exp) => sum + exp.amount, 0);
  const monthlyAverage = totalSpent / (expenses.length || 1);

  return (
    <div className="space-y-6">
      {/* Summary Cards */}
      <div className="grid grid-cols-2 gap-4">
        <div className="bg-gradient-to-br from-green-50 to-green-100/50 p-6 rounded-3xl border-2 border-green-200">
          <DollarSign size={32} className="text-green-600 mb-2" />
          <div className="text-2xl font-black text-green-700">${totalSpent.toFixed(2)}</div>
          <div className="text-xs font-bold text-green-600 uppercase">Total Spent</div>
        </div>
        <div className="bg-gradient-to-br from-blue-50 to-blue-100/50 p-6 rounded-3xl border-2 border-blue-200">
          <TrendingUp size={32} className="text-blue-600 mb-2" />
          <div className="text-2xl font-black text-blue-700">${monthlyAverage.toFixed(2)}</div>
          <div className="text-xs font-bold text-blue-600 uppercase">Per Entry Avg</div>
        </div>
      </div>

      {/* Add Expense Form */}
      <div className="bg-white p-6 rounded-3xl border-2 border-[#EDE0CE] shadow-sm">
        <h3 className="text-xs font-black text-[#8A7560] uppercase tracking-wider mb-4">
          Log New Expense
        </h3>
        <div className="space-y-3">
          <select
            value={newExpense.category}
            onChange={(e) => setNewExpense({ ...newExpense, category: e.target.value })}
            className="w-full p-4 bg-stone-50 rounded-2xl border-2 border-transparent focus:border-[#E8621A] outline-none font-bold"
          >
            <option value="">Select Category</option>
            {categories.map(cat => (
              <option key={cat.name} value={cat.name}>{cat.name}</option>
            ))}
          </select>

          <div className="grid grid-cols-2 gap-3">
            <input
              type="number"
              step="0.01"
              placeholder="Amount ($)"
              value={newExpense.amount}
              onChange={(e) => setNewExpense({ ...newExpense, amount: e.target.value })}
              className="p-4 bg-stone-50 rounded-2xl border-2 border-transparent focus:border-[#E8621A] outline-none font-bold"
            />
            <input
              type="date"
              value={newExpense.date}
              onChange={(e) => setNewExpense({ ...newExpense, date: e.target.value })}
              className="p-4 bg-stone-50 rounded-2xl border-2 border-transparent focus:border-[#E8621A] outline-none font-bold"
            />
          </div>

          <input
            type="text"
            placeholder="Description (optional)"
            value={newExpense.description}
            onChange={(e) => setNewExpense({ ...newExpense, description: e.target.value })}
            className="w-full p-4 bg-stone-50 rounded-2xl border-2 border-transparent focus:border-[#E8621A] outline-none font-bold"
          />

          <button
            onClick={addExpense}
            className="w-full py-4 bg-[#E8621A] text-white rounded-2xl font-black text-sm hover:bg-[#D55614] transition-all"
          >
            Add Expense
          </button>
        </div>
      </div>

      {/* Expense List */}
      <div className="space-y-3">
        <h3 className="text-xs font-black text-[#8A7560] uppercase tracking-wider">
          Recent Expenses
        </h3>
        {expenses.length === 0 ? (
          <div className="text-center py-8 bg-stone-50 rounded-3xl">
            <DollarSign size={40} className="mx-auto text-stone-300 mb-2" />
            <p className="text-sm font-bold text-stone-400">No expenses logged yet</p>
          </div>
        ) : (
          expenses.map(exp => {
            const category = categories.find(c => c.name === exp.category);
            const Icon = category?.icon || DollarSign;
            return (
              <motion.div
                key={exp.id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                className={`${category?.bg || 'bg-stone-50'} p-4 rounded-2xl border border-white`}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <Icon size={20} className={category?.color || 'text-stone-500'} />
                    <div>
                      <div className="font-black text-[#423D38]">{exp.category}</div>
                      {exp.description && (
                        <div className="text-xs text-stone-500">{exp.description}</div>
                      )}
                      <div className="text-xs text-stone-400 font-medium">{exp.date}</div>
                    </div>
                  </div>
                  <div className="text-lg font-black text-[#E8621A]">
                    ${exp.amount.toFixed(2)}
                  </div>
                </div>
              </motion.div>
            );
          })
        )}
      </div>
    </div>
  );
};

export default ExpenseTracker;
```

## 4. 🎓 Training Progress Tracker

```javascript
// TrainingTracker.jsx
import React, { useState } from 'react';
import { Brain, CheckCircle2, Circle, Star, TrendingUp } from 'lucide-react';
import { motion } from 'framer-motion';

const TrainingTracker = () => {
  const [tricks, setTricks] = useState([
    { id: 1, name: 'Sit', mastery: 100, lastPracticed: '2024-03-20' },
    { id: 2, name: 'Stay', mastery: 75, lastPracticed: '2024-03-19' },
    { id: 3, name: 'Roll Over', mastery: 40, lastPracticed: '2024-03-18' },
    { id: 4, name: 'Fetch', mastery: 90, lastPracticed: '2024-03-20' },
  ]);

  const updateMastery = (id, change) => {
    setTricks(tricks.map(trick => 
      trick.id === id 
        ? { ...trick, mastery: Math.max(0, Math.min(100, trick.mastery + change)) }
        : trick
    ));
  };

  const getMasteryColor = (mastery) => {
    if (mastery >= 80) return 'bg-green-500';
    if (mastery >= 50) return 'bg-yellow-500';
    return 'bg-orange-500';
  };

  const getMasteryLabel = (mastery) => {
    if (mastery >= 80) return 'Mastered';
    if (mastery >= 50) return 'Learning';
    return 'Beginner';
  };

  const averageMastery = tricks.reduce((sum, t) => sum + t.mastery, 0) / tricks.length;

  return (
    <div className="space-y-6">
      {/* Progress Summary */}
      <div className="bg-gradient-to-br from-purple-50 to-purple-100/50 p-6 rounded-3xl border-2 border-purple-200">
        <div className="flex items-center gap-4">
          <Brain size={48} className="text-purple-600" />
          <div className="flex-1">
            <div className="text-3xl font-black text-purple-700">{averageMastery.toFixed(0)}%</div>
            <div className="text-xs font-bold text-purple-600 uppercase mb-2">Overall Progress</div>
            <div className="h-2 bg-purple-200 rounded-full overflow-hidden">
              <div 
                className="h-full bg-purple-600 rounded-full transition-all duration-500"
                style={{ width: `${averageMastery}%` }}
              />
            </div>
          </div>
        </div>
      </div>

      {/* Tricks List */}
      <div className="space-y-4">
        <h3 className="text-xs font-black text-[#8A7560] uppercase tracking-wider flex items-center gap-2">
          <Star size={14} /> Training Skills
        </h3>
        {tricks.map(trick => (
          <motion.div
            key={trick.id}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-white p-6 rounded-3xl border-2 border-[#EDE0CE] shadow-sm"
          >
            <div className="flex items-center justify-between mb-3">
              <div>
                <h4 className="font-black text-[#423D38] text-lg">{trick.name}</h4>
                <span className={`text-xs font-bold px-3 py-1 rounded-full ${
                  trick.mastery >= 80 ? 'bg-green-100 text-green-700' :
                  trick.mastery >= 50 ? 'bg-yellow-100 text-yellow-700' :
                  'bg-orange-100 text-orange-700'
                }`}>
                  {getMasteryLabel(trick.mastery)}
                </span>
              </div>
              <div className="text-2xl font-black text-[#E8621A]">
                {trick.mastery}%
              </div>
            </div>

            <div className="h-3 bg-stone-100 rounded-full overflow-hidden mb-4">
              <div 
                className={`h-full ${getMasteryColor(trick.mastery)} rounded-full transition-all duration-500`}
                style={{ width: `${trick.mastery}%` }}
              />
            </div>

            <div className="flex gap-2">
              <button
                onClick={() => updateMastery(trick.id, -10)}
                className="flex-1 py-2 bg-stone-100 hover:bg-stone-200 rounded-xl text-sm font-bold text-stone-600 transition-colors"
              >
                - Progress
              </button>
              <button
                onClick={() => updateMastery(trick.id, 10)}
                className="flex-1 py-2 bg-green-500 hover:bg-green-600 text-white rounded-xl text-sm font-bold transition-colors"
              >
                + Progress
              </button>
            </div>

            <div className="text-xs text-stone-400 font-medium mt-2 text-center">
              Last practiced: {trick.lastPracticed}
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
};

export default TrainingTracker;
```

## 5. 🏆 Achievement System

```javascript
// AchievementSystem.jsx
import React from 'react';
import { Award, Star, Heart, TrendingUp, Calendar } from 'lucide-react';
import { motion } from 'framer-motion';

const AchievementSystem = ({ activities, supplies }) => {
  const achievements = [
    {
      id: 1,
      icon: Calendar,
      title: 'First Week',
      description: 'Logged activities for 7 days',
      progress: Math.min(100, (activities.length / 7) * 100),
      unlocked: activities.length >= 7,
      color: 'blue'
    },
    {
      id: 2,
      icon: Heart,
      title: 'Caring Parent',
      description: 'Completed 20 activities',
      progress: Math.min(100, (activities.length / 20) * 100),
      unlocked: activities.length >= 20,
      color: 'red'
    },
    {
      id: 3,
      icon: Star,
      title: 'Supply Master',
      description: 'Keep supply inventory updated',
      progress: Math.min(100, (supplies.filter(s => s.checked).length / supplies.length) * 100),
      unlocked: supplies.filter(s => s.checked).length === supplies.length,
      color: 'yellow'
    },
    {
      id: 4,
      icon: TrendingUp,
      title: 'Consistency King',
      description: 'Log activities 3 days in a row',
      progress: 60,
      unlocked: false,
      color: 'green'
    }
  ];

  const colorMap = {
    blue: { bg: 'bg-blue-50', text: 'text-blue-600', border: 'border-blue-200' },
    red: { bg: 'bg-red-50', text: 'text-red-600', border: 'border-red-200' },
    yellow: { bg: 'bg-yellow-50', text: 'text-yellow-600', border: 'border-yellow-200' },
    green: { bg: 'bg-green-50', text: 'text-green-600', border: 'border-green-200' }
  };

  return (
    <div className="space-y-4">
      <h3 className="text-xs font-black text-[#8A7560] uppercase tracking-wider flex items-center gap-2">
        <Award size={14} /> Your Achievements
      </h3>
      {achievements.map(achievement => {
        const Icon = achievement.icon;
        const colors = colorMap[achievement.color];
        return (
          <motion.div
            key={achievement.id}
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className={`${colors.bg} p-6 rounded-3xl border-2 ${colors.border} ${
              achievement.unlocked ? 'shadow-lg' : 'opacity-60'
            }`}
          >
            <div className="flex items-start gap-4">
              <div className={`p-3 bg-white rounded-2xl ${achievement.unlocked ? 'shadow-md' : ''}`}>
                <Icon size={24} className={colors.text} />
              </div>
              <div className="flex-1">
                <h4 className="font-black text-[#423D38] mb-1">{achievement.title}</h4>
                <p className="text-xs text-stone-600 mb-3">{achievement.description}</p>
                <div className="flex items-center gap-3">
                  <div className="flex-1 h-2 bg-white rounded-full overflow-hidden">
                    <div 
                      className={`h-full ${achievement.unlocked ? 'bg-gradient-to-r from-green-400 to-green-600' : colors.text.replace('text', 'bg')} rounded-full transition-all duration-500`}
                      style={{ width: `${achievement.progress}%` }}
                    />
                  </div>
                  <span className="text-xs font-black text-stone-600">
                    {achievement.progress.toFixed(0)}%
                  </span>
                </div>
                {achievement.unlocked && (
                  <div className="mt-2 inline-block px-3 py-1 bg-green-500 text-white text-xs font-black rounded-full">
                    UNLOCKED! 🎉
                  </div>
                )}
              </div>
            </div>
          </motion.div>
        );
      })}
    </div>
  );
};

export default AchievementSystem;
```

## How to Use These Components

### 1. Add to Your Enhanced App

```javascript
// In App_Enhanced.jsx, import at the top:
import PhotoGallery from './components/PhotoGallery';
import AppointmentScheduler from './components/AppointmentScheduler';
import ExpenseTracker from './components/ExpenseTracker';
import TrainingTracker from './components/TrainingTracker';
import AchievementSystem from './components/AchievementSystem';

// Add new tabs to your tab navigation:
const tabs = [
  { id: 'home', label: 'Home', icon: Home },
  { id: 'health', label: 'Health', icon: Stethoscope },
  { id: 'stats', label: 'Stats', icon: BarChart3 },
  { id: 'gallery', label: 'Photos', icon: Camera },
  { id: 'appointments', label: 'Calendar', icon: Calendar },
  { id: 'expenses', label: 'Budget', icon: DollarSign },
  { id: 'training', label: 'Training', icon: Brain },
  { id: 'profile', label: 'Profile', icon: User },
];

// Add corresponding tab content sections:
{currentTab === 'gallery' && (
  <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
    <PhotoGallery />
  </motion.div>
)}

{currentTab === 'appointments' && (
  <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
    <AppointmentScheduler />
  </motion.div>
)}

// etc...
```

### 2. File Structure

```
src/
├── App.jsx (your enhanced main component)
├── components/
│   ├── PhotoGallery.jsx
│   ├── AppointmentScheduler.jsx
│   ├── ExpenseTracker.jsx
│   ├── TrainingTracker.jsx
│   └── AchievementSystem.jsx
├── main.jsx
└── index.css
```

## 🎯 Premium Features Roadmap

These bonus components unlock:
- ✅ **Photo Gallery** - Pet memory timeline
- ✅ **Appointment Scheduler** - Never miss vet visits
- ✅ **Expense Tracker** - Budget management
- ✅ **Training Progress** - Skill development tracking
- ✅ **Achievement System** - Gamification & engagement

## 💡 Monetization Ideas for These Features

1. **Free Tier**: 
   - 5 photos max
   - 2 appointments
   - Basic expense tracking

2. **Pro Tier ($4.99/month)**:
   - Unlimited photos with cloud backup
   - Unlimited appointments with reminders
   - Advanced expense reports & budgeting
   - Full training tracker with AI suggestions
   - All achievements unlocked

3. **Ultimate Tier ($9.99/month)**:
   - Everything in Pro
   - Photo albums with sharing
   - Calendar sync (Google, Apple)
   - Export expense reports (PDF, Excel)
   - Custom training programs

Happy coding! 🐾
