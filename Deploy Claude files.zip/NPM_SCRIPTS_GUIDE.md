# 📦 Add These Scripts to Your package.json

## Quick Setup

Open your `package.json` file and add these scripts to the `"scripts"` section:

```json
{
  "name": "pawpad",
  "private": true,
  "version": "0.0.0",
  "type": "module",
  "scripts": {
    "dev": "vite",
    "build": "vite build",
    "preview": "vite preview",
    
    "deploy": "git add . && git commit -m 'Update' && git push",
    "deploy:msg": "git add . && git commit && git push",
    "deploy:quick": "npm run build && git add . && git commit -m 'Quick deploy' && git push",
    "deploy:prod": "npm run build && vercel --prod",
    "status": "git status",
    "logs": "vercel logs"
  },
  "dependencies": {
    // ... your dependencies
  }
}
```

## Usage

After adding these scripts, you can use:

### 1. Quick Deploy (Auto Message)
```bash
npm run deploy
```
Commits with message "Update" and pushes to GitHub

### 2. Deploy with Custom Message
```bash
npm run deploy:msg
```
Will prompt you to enter a commit message

### 3. Build + Deploy
```bash
npm run deploy:quick
```
Builds the project first, then deploys

### 4. Direct to Vercel Production
```bash
npm run deploy:prod
```
Builds and deploys directly to Vercel production

### 5. Check Status
```bash
npm run status
```
Shows git status (what files changed)

### 6. View Logs
```bash
npm run logs
```
Shows Vercel deployment logs

## Complete Example package.json

Here's a full example you can copy:

```json
{
  "name": "pawpad",
  "private": true,
  "version": "1.0.0",
  "description": "Pet care tracking app",
  "type": "module",
  "scripts": {
    "dev": "vite",
    "build": "vite build",
    "preview": "vite preview",
    "deploy": "git add . && git commit -m 'Update' && git push",
    "deploy:msg": "git add . && git commit && git push",
    "deploy:quick": "npm run build && git add . && git commit -m 'Quick deploy' && git push",
    "deploy:prod": "npm run build && vercel --prod",
    "status": "git status",
    "logs": "vercel logs"
  },
  "dependencies": {
    "react": "^18.2.0",
    "react-dom": "^18.2.0",
    "lucide-react": "^0.263.1",
    "framer-motion": "^10.16.4"
  },
  "devDependencies": {
    "@types/react": "^18.2.15",
    "@types/react-dom": "^18.2.7",
    "@vitejs/plugin-react": "^4.0.3",
    "autoprefixer": "^10.4.14",
    "postcss": "^8.4.27",
    "tailwindcss": "^3.3.3",
    "vite": "^4.4.5"
  }
}
```

## Your New Workflow

```bash
# Make edits to your code
# ...

# Deploy
npm run deploy

# Done! 🎉
```

That's it! Super simple deployment every time! 🚀
