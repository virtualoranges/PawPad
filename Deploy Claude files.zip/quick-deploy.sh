#!/bin/bash

# 🐾 PawPad Quick Deploy Script
# Usage: ./quick-deploy.sh "your commit message"
# Or just: ./quick-deploy.sh (uses auto-generated message)

echo "🐾 =================================="
echo "   PawPad Deployment Starting..."
echo "=================================="
echo ""

# Check if we're in a git repository
if [ ! -d .git ]; then
    echo "❌ Error: Not a git repository!"
    echo "Run 'git init' first"
    exit 1
fi

# Check for uncommitted changes
if [[ -z $(git status -s) ]]; then
    echo "✨ No changes to deploy"
    echo ""
    echo "💡 Tip: Make some edits first, then run this script"
    exit 0
fi

echo "📝 Changes detected:"
git status -s
echo ""

# Get commit message
if [ -z "$1" ]; then
    # Auto-generate commit message with timestamp
    COMMIT_MSG="Update: $(date '+%Y-%m-%d %H:%M')"
    echo "📋 Using auto-generated commit message:"
    echo "   \"$COMMIT_MSG\""
else
    COMMIT_MSG="$1"
    echo "📋 Commit message: \"$COMMIT_MSG\""
fi
echo ""

# Add all changes
echo "➕ Adding all changes..."
git add .

# Commit
echo "💾 Committing changes..."
git commit -m "$COMMIT_MSG"

# Check if commit was successful
if [ $? -ne 0 ]; then
    echo "❌ Commit failed!"
    exit 1
fi

# Push to GitHub
echo "🚀 Pushing to GitHub..."
git push

# Check if push was successful
if [ $? -eq 0 ]; then
    echo ""
    echo "✅ =================================="
    echo "   Successfully Deployed!"
    echo "=================================="
    echo ""
    echo "🌐 Vercel will auto-deploy in ~30 seconds"
    echo "📊 Check status: https://vercel.com/dashboard"
    echo "🔗 Your site: https://paw-pad.vercel.app"
    echo ""
    echo "💡 Tip: Run 'vercel ls' to see deployment status"
else
    echo ""
    echo "❌ =================================="
    echo "   Push Failed!"
    echo "=================================="
    echo ""
    echo "💡 Possible solutions:"
    echo "   1. Run: git pull"
    echo "   2. Then run this script again"
    echo "   3. Or check your internet connection"
fi
